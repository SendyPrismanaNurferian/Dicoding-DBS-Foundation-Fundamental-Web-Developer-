class AppBar extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
    }

    connectedCallback() {
        this.shadowRoot.innerHTML = `
            <style>
                :host {
                    display: block;
                    background-color: #6200ea;
                    color: white;
                    padding: 1rem;
                    text-align: center;
                    font-size: 1.5rem;
                }
            </style>
            <div>
                <slot></slot>
            </div>
        `;
    }
}

customElements.define('app-bar', AppBar);
