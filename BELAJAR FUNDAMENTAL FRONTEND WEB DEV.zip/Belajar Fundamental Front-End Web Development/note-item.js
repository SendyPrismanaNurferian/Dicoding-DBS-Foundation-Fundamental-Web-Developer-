class NoteItem extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
    }

    connectedCallback() {
        const title = this.getAttribute('title');
        const body = this.getAttribute('body');
        const createdAt = new Date(this.getAttribute('createdAt')).toLocaleDateString();

        this.shadowRoot.innerHTML = `
            <style>
                .note {
                    background-color: white;
                    border: 1px solid #ddd;
                    padding: 1rem;
                    border-radius: 8px;
                    margin-bottom: 1rem;
                }
                .note h3 {
                    margin-top: 0;
                }
            </style>
            <div class="note">
                <h3>${title}</h3>
                <p>${body}</p>
                <small>Created on: ${createdAt}</small>
            </div>
        `;
    }
}

customElements.define('note-item', NoteItem);
