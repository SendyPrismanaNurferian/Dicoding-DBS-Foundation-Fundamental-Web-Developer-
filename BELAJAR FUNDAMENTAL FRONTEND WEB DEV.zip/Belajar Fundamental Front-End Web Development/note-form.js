class NoteForm extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
    }

    connectedCallback() {
        this.shadowRoot.innerHTML = `
            <style>
                form {
                    display: grid;
                    gap: 1rem;
                }
                label {
                    font-weight: bold;
                }
                input, textarea {
                    width: 100%;
                    padding: 0.5rem;
                    border: 1px solid #ddd;
                    border-radius: 4px;
                }
                button {
                    padding: 0.5rem;
                    border: none;
                    background-color: #6200ea;
                    color: white;
                    cursor: pointer;
                    border-radius: 4px;
                }
                button:hover {
                    background-color: #3700b3;
                }
            </style>
            <form id="note-form">
                <label for="title">Judul:</label>
                <input type="text" id="title" name="title" required>
                <label for="body">Isi:</label>
                <textarea id="body" name="body" required></textarea>
                <button type="submit">Tambah Catatan</button>
            </form>
        `;

        this.shadowRoot.querySelector('form').addEventListener('submit', (event) => {
            event.preventDefault();
            const title = event.target.title.value;
            const body = event.target.body.value;
            const createdAt = new Date().toISOString();

            const noteEvent = new CustomEvent('note-added', {
                detail: {
                    title,
                    body,
                    createdAt,
                },
                bubbles: true,
                composed: true,
            });

            this.dispatchEvent(noteEvent);
            event.target.reset();
        });
    }
}

customElements.define('note-form', NoteForm);
